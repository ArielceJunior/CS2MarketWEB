/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.arielce_kawan_cs2marketweb.modelo.entidade;

/**
 *
 * @author ariel
 */
public class Raridade {
    private Integer idRar;
    private String nomeRar;

    public Integer getIdRar() {
        return idRar;
    }

    public void setIdRar(Integer idRar) {
        this.idRar = idRar;
    }

    public String getNomeRar() {
        return nomeRar;
    }

    public void setNomeRar(String nomeRar) {
        this.nomeRar = nomeRar;
    }
    
    
    
}
