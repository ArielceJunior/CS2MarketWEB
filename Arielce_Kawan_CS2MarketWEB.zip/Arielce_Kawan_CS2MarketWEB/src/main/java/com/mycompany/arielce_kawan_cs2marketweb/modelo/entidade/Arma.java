/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.arielce_kawan_cs2marketweb.modelo.entidade;

/**
 *
 * @author ariel
 */
public class Arma {
      private Integer idArma;
    private String nomeArma;

    public Integer getIdArma() {
        return idArma;
    }

    public void setIdArma(Integer idArma) {
        this.idArma = idArma;
    }

    public String getNomeArma() {
        return nomeArma;
    }

    public void setNomeArma(String nomeArma) {
        this.nomeArma = nomeArma;
    }
}
